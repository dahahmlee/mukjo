package com.example.model1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MainTeamTO{
		private String seq;
		private String tname;
		private String tseq;
		private String jangseq;
		private String jangname;
		private int memcount;
		private String accept;
}
