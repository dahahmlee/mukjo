package com.example.model1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuTO {
   private String rmenuname;
   private String rmenuimage;
   private String rmenuprice;
}