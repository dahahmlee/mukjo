package com.example.model1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberTO {
	private String seq;
	private String email;
	private String password;
	private String name;
	private String phone;
	private String date;
	private String birth;
}
