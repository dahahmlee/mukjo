package com.example.model1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewTO {
	private String rseq;
	private String tseq;
	private String seq;
	private String writer;
	private String rest;
	private String rcontent;
	private String star;
	private String rdate;
	
	
}
