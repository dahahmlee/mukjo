package com.example.model1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentTO {
	private String cseq;
	private String bseq;
	private String seq;
	private String cContent;
	private String cDate;
	private String writer;
}
